export default function Deck() {
  let deck = {
    cards: [],
  };
  return (
    <div>
      <button className="drawButton">dih</button>
    </div>
  );
}
