import data from "../data/data.json";
export default function Deck() {
  let deck = {
    cards: data.pokemon,
  };
  let card = deck.cards[1];
  return (
    <div>
      <button
        className="drawButton"
        onClick={() => {
          //let idx = Math.floor(Math.random() * deck.cards.length);
          if (deck.cards.length > 0) {
            card = deck.cards.pop();

            console.log(card);
          } else {
            console.log("No cards in deck");
          }
        }}
      >
        dih
      </button>
      <img src={card.image} alt="Card Not Found" className="cardImage" />
    </div>
  );
}
